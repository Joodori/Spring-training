package myspring;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

// EmpServiceImpl이 EmpDAO를 의존하고 있다.

@Component("empService")
public class EmpServiceImpl implements EmpService {
	
	EmpDAO dao;

	public EmpServiceImpl(EmpDAO dao) {
		this.dao = dao;
	}

	@Override
	public List<Emp> findEmpByYear(int year) throws Exception {
		return dao.findEmpByYear(year);
	}

	@Override
	public List<Emp> getEmpListByDeptNo(int deptNo) throws Exception {
		return null;
	}

	@Override
	public List<Emp> findEmpByDeptId(int deptId) throws Exception {
		return dao.findEmpByDeptId(deptId);
	}

	@Override
	public List<Emp> findEmpByFirstName(String firstName) throws Exception {
		return dao.findEmpByFirstName(firstName);
	}

	@Override
	public List<Emp> findEmpByCityName(String cityName) throws Exception {
		return dao.findEmpByCityName(cityName);
	}

	@Override
	public List<Emp> getEmpByFirstNLastName(String firstName, String lastName) {
		return dao.getEmpByFirstNLastName(firstName, lastName);
	}

}
