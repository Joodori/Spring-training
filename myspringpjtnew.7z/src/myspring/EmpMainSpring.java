package myspring;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmpMainSpring {
	public static void main(String[] args) throws Exception {
		int deptNo = 60;

		ApplicationContext context = new ClassPathXmlApplicationContext("spring-context.xml");
		EmpService service = (EmpService) context.getBean(EmpService.class);
		
		String firstName = "Samuel";
		String lastName = null;
		List<Emp> empList = service.getEmpByFirstNLastName(firstName, lastName);
		
		if (empList.size() == 0 ) {
			System.out.println("존재하지 않음");
		}
		for (Emp emp : empList) {
			System.out.println(emp);
		}

	}
}
